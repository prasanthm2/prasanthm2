# frontend

Place all frontend code in this directory; this includes HTML, CSS, and JavaScript files. Additionally, place any images, fonts, or other assets in this directory. Bootstrap and jQuery are to be included in this directory.
